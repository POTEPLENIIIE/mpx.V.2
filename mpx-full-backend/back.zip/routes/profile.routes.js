import express from "express";
import multer from "multer";
import path from "path";
import { verifyToken } from "../middleware/auth.middleware.js";
import {
  getUserData,
  updateAvatar,
} from "../controllers/profile.controller.js";

const router = express.Router();

// 💾 Налаштування сховища для multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/avatars");
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const uniqueName = `${req.user.username}_Avatar${ext}`;
    cb(null, uniqueName);
  },
});

// ✅ Створення upload
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext !== ".jpg" && ext !== ".jpeg") {
      return cb(new Error("Дозволено лише JPG файли"));
    }
    cb(null, true);
  },
});

// ✅ Отримання профілю
router.get("/me", verifyToken, getUserData);

// ✅ Оновлення аватару
router.post(
  "/avatar",
  verifyToken,
  upload.single("avatar"),
  (req, res, next) => {
    console.log("📸 Отримано файл:", req.file);
    console.log("👤 Користувач:", req.user);
    next();
  },
  updateAvatar
);

export default router;

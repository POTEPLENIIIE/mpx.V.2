import fs from "fs";
import path from "path";
import User from "../models/User.js";

// ✅ Отримати дані користувача
export const getUserData = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    if (!user) {
      return res.status(404).json({ message: "Користувача не знайдено" });
    }
    res.json(user);
  } catch (error) {
    console.error("Помилка сервера:", error);
    res.status(500).json({ message: "Помилка сервера" });
  }
};

// ✅ Оновити аватар
export const updateAvatar = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user)
      return res.status(404).json({ message: "Користувача не знайдено" });

    if (!req.file)
      return res.status(400).json({ message: "Файл не завантажено" });

    const newAvatar = req.file.filename;

    // Видаляємо старий аватар, якщо не дефолтний
    if (user.avatar && user.avatar !== "default-avatar.webp") {
      const oldPath = path.join("uploads/avatars", user.avatar);
      if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
    }

    user.avatar = newAvatar;
    await user.save();

    res.json({ message: "Аватар оновлено", avatar: newAvatar });
  } catch (err) {
    console.error("Помилка при оновленні аватару:", err);
    res.status(500).json({ message: "Помилка сервера" });
  }
};

import { Component, OnInit } from "@angular/core";
import { NavbarComponent } from "../navbar/navbar.component";
import { FooterComponent } from "../footer/footer.component";
import { UserService } from "../services/user.service";

@Component({
  selector: "app-profile",
  standalone: true,
  imports: [NavbarComponent, FooterComponent],
  templateUrl: "./profile.component.html",
  styleUrl: "./profile.component.css",
})
export class ProfileComponent {
  userData: any = {}; // Зберігаємо дані користувача
  errorMessage: string = ""; // Повідомлення про помилку

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.getUserData(); // Отримуємо дані при завантаженні компонента
  }

  getUserData() {
    this.userService.getUserProfile().subscribe({
      next: (data) => {
        console.log("Отримані дані користувача:", data); // Логування для перевірки
        this.userData = data; // Оновлюємо дані
      },
      error: (error) => {
        console.error("Помилка отримання даних:", error);
        this.errorMessage = "Не вдалося завантажити дані користувача.";
      },
    });
  }
}

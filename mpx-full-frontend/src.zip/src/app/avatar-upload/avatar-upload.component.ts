import {
  Component,
  EventEmitter,
  Output,
  ViewChild,
  ElementRef,
} from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Component({
  selector: "app-avatar-upload",
  standalone: true,
  templateUrl: "./avatar-upload.component.html",
  styleUrl: "./avatar-upload.component.scss",
})
export class AvatarUploadComponent {
  @ViewChild("fileInput") fileInput!: ElementRef<HTMLInputElement>;
  selectedFile: File | null = null;
  previewUrl: string | null = null;
  @Output() avatarUpdated = new EventEmitter<void>();

  constructor(private http: HttpClient) {}

  triggerFileInput() {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;

    if (input.files && input.files.length > 0) {
      const file = input.files[0];

      if (!file.name.endsWith(".jpg") && !file.name.endsWith(".jpeg")) {
        alert("❌ Дозволено лише JPG-файли");
        input.value = ""; // очищаємо тільки після перевірки
        return;
      }

      this.selectedFile = file;

      const reader = new FileReader();
      reader.onload = () => {
        this.previewUrl = reader.result as string;
        console.log("📷 Превʼю готове:", this.previewUrl);
      };
      reader.readAsDataURL(file);
    }

    // очищаємо вибір, щоб можна було вибирати той самий файл знову
    input.value = "";
  }

  uploadAvatar(): void {
    if (!this.selectedFile) return;

    console.log("🚀 Надсилаємо аватар...");
    const formData = new FormData();
    formData.append("avatar", this.selectedFile);

    const token = localStorage.getItem("token");
    if (!token) {
      alert("❗ Токен не знайдено");
      return;
    }

    const headers = new HttpHeaders().set("Authorization", `Bearer ${token}`);

    this.http
      .post("http://localhost:4000/api/profile/avatar", formData, { headers })
      .subscribe({
        next: () => {
          console.log("✅ Аватар оновлено");
          this.avatarUpdated.emit();
          this.selectedFile = null;
          this.previewUrl = null;
        },
        error: (err) => {
          console.error("❌ Помилка при завантаженні аватара:", err);
          alert("Не вдалося завантажити аватар.");
        },
      });
  }
}
